package wumpusworld;


public class Block {
        public int x;
        public int y;
        public boolean Wum_pus = false;
        public boolean breeze = false;
        public boolean pit = false;
        public boolean stench = false;
        public boolean gold = false;
        public boolean Danger = false;
        public boolean safe = false;
        public boolean visited = false;
        public boolean marked = false;
        Double probability = 0.0;
    }
